### GSMultipleChoiceView
实现列表的多级筛选功能，并记忆上次选中的选项，可增加多种筛选条件
![介绍图片1](https://github.com/zhangguosen3033/GSMultipleChoiceView/blob/master/演示gif03.gif)

网络请求筛选如下图：


![介绍图片1](https://github.com/zhangguosen3033/GSMultipleChoiceView/blob/master/演示gif01.gif)
![介绍图片1](https://github.com/zhangguosen3033/GSMultipleChoiceView/blob/master/演示gif02.gif)
