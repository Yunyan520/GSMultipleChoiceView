//
//  AppDelegate.h
//  GSMultipleChoiceView
//
//  Created by ygkj on 2017/6/12.
//  Copyright © 2017年 ygkj. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

