//
//  ViewController.h
//  GSMultipleChoiceView
//
//  Created by ygkj on 2017/6/12.
//  Copyright © 2017年 ygkj. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property(nonatomic,strong)UIView *SlectbottomView;

@end

